# Historic Legacy Code - Crypto Trading Bots

This sub-folder was created to store deprecated and historic versions of the crypto trading bots in above folder, in order to keep things cleaner and more organized in both folders. 

These historic legacy bots are kept in order to allow understanding / access of bots at earlier stage of development. 

Please see readme of higher folder for more detailed instructions.
